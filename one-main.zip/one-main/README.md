# tonyff
备份自用，就是为了修改facefusion的几行代码，适合在Colab上使用！ 
