#!/usr/bin/env python3

from fan import core

if __name__ == '__main__':
    core.cli()
